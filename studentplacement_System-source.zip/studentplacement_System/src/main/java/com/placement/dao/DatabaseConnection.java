package com.placement.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Properties;

public final class DatabaseConnection {
    private static final String DEFAULT_URL = "jdbc:mysql://localhost:3306/chs_placement_portal?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC";
    private static final Path LOCAL_CONFIG = Paths.get(
            System.getProperty("user.home"), "Documents", "Codex", ".placement-db.properties");

    private DatabaseConnection() { }

    public static Connection initializeDatabase() throws SQLException {
        String url = setting("PLACEMENT_DB_URL", DEFAULT_URL);
        String user = setting("PLACEMENT_DB_USER", "root");
        String password = setting("PLACEMENT_DB_PASSWORD", "");
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException ex) {
            throw new SQLException("MySQL Connector/J is missing from the deployed application.", ex);
        }
        return DriverManager.getConnection(url, user, password);
    }

    private static String setting(String name, String fallback) {
        String value = System.getenv(name);
        if (value != null && !value.trim().isEmpty()) return value.trim();

        Properties properties = new Properties();
        try (InputStream input = Files.newInputStream(LOCAL_CONFIG)) {
            properties.load(input);
            value = properties.getProperty(name);
        } catch (IOException ignored) {
            // Environment variables and defaults remain available when no local config exists.
        }
        return value == null || value.trim().isEmpty() ? fallback : value.trim();
    }
}
