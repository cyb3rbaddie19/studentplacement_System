package com.placement.controller;

import com.placement.dao.DatabaseConnection;
import com.placement.security.PasswordHasher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.security.GeneralSecurityException;

@WebServlet(name = "LoginServlet", urlPatterns = {"/LoginServlet"})
public class LoginServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String email = value(request.getParameter("email")).toLowerCase();
        String password = request.getParameter("password");
        String requestedRole = value(request.getParameter("role"));
        String context = request.getContextPath();

        if (email.isEmpty() || password == null || password.isEmpty()) {
            response.sendRedirect(context + "/index.jsp?error=invalid");
            return;
        }

        String sql = "SELECT id, full_name, password_hash, role, status FROM users WHERE email = ?";
        try (Connection connection = DatabaseConnection.initializeDatabase();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, email);
            try (ResultSet user = statement.executeQuery()) {
                if (!user.next() || !"active".equals(user.getString("status"))
                        || !requestedRole.equals(user.getString("role"))
                        || !PasswordHasher.verify(password.toCharArray(), user.getString("password_hash"))) {
                    response.sendRedirect(context + "/index.jsp?error=invalid");
                    return;
                }
                HttpSession session = request.getSession(true);
                request.changeSessionId();
                session.setAttribute("userId", user.getLong("id"));
                session.setAttribute("userName", user.getString("full_name"));
                session.setAttribute("userRole", user.getString("role"));
                String destination;
                switch (user.getString("role")) {
                    // Students see preferences only when first-time onboarding is incomplete.
                    case "student": destination = "/PortalServlet"; break;
                    case "recruiter": destination = "/PortalServlet"; break;
                    case "admin": destination = "/PortalServlet"; break;
                    default: destination = "/index.jsp?error=invalid";
                }
                response.sendRedirect(context + destination);
            }
        } catch (SQLException | GeneralSecurityException ex) {
            getServletContext().log("Placement portal login failed", ex);
            response.sendRedirect(context + "/index.jsp?error=unavailable");
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.sendRedirect(request.getContextPath() + "/index.jsp");
    }

    private static String value(String value) {
        return value == null ? "" : value.trim();
    }
}
