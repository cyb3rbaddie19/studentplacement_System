package com.placement.controller;

import com.placement.dao.DatabaseConnection;
import com.placement.security.PasswordHasher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.security.GeneralSecurityException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.Year;

@WebServlet(name = "RegisterServlet", urlPatterns = {"/RegisterServlet"})
public class RegisterServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        String name = value(request.getParameter("fullName"));
        String email = value(request.getParameter("email")).toLowerCase();
        String studentNumber = value(request.getParameter("studentNumber"));
        String program = value(request.getParameter("program"));
        String password = request.getParameter("password");
        String confirmPassword = request.getParameter("confirmPassword");
        String context = request.getContextPath();
        int graduationYear;
        try { graduationYear = Integer.parseInt(request.getParameter("graduationYear")); }
        catch (NumberFormatException ex) { response.sendRedirect(context + "/register.jsp?error=invalid"); return; }

        if (name.length() < 2 || name.length() > 120 || !email.matches("^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$")
                || studentNumber.isEmpty() || studentNumber.length() > 40 || program.isEmpty()
                || graduationYear < Year.now().getValue() || graduationYear > Year.now().getValue() + 8
                || password == null || password.length() < 10 || !password.equals(confirmPassword)) {
            response.sendRedirect(context + "/register.jsp?error=invalid");
            return;
        }

        String userSql = "INSERT INTO users (full_name, email, password_hash, role, status) VALUES (?, ?, ?, 'student', 'active')";
        String studentSql = "INSERT INTO students (user_id, student_number, program, graduation_year) VALUES (?, ?, ?, ?)";
        try (Connection connection = DatabaseConnection.initializeDatabase()) {
            connection.setAutoCommit(false);
            try (PreparedStatement userStatement = connection.prepareStatement(userSql, Statement.RETURN_GENERATED_KEYS)) {
                userStatement.setString(1, name);
                userStatement.setString(2, email);
                userStatement.setString(3, PasswordHasher.hash(password.toCharArray()));
                userStatement.executeUpdate();
                try (var keys = userStatement.getGeneratedKeys()) {
                    if (!keys.next()) throw new SQLException("Could not create student account.");
                    long userId = keys.getLong(1);
                    try (PreparedStatement studentStatement = connection.prepareStatement(studentSql)) {
                        studentStatement.setLong(1, userId);
                        studentStatement.setString(2, studentNumber);
                        studentStatement.setString(3, program);
                        studentStatement.setInt(4, graduationYear);
                        studentStatement.executeUpdate();
                    }
                }
                connection.commit();
                response.sendRedirect(context + "/index.jsp?registered=1");
            } catch (SQLException | GeneralSecurityException ex) {
                connection.rollback();
                if (ex instanceof SQLException && "23000".equals(((SQLException) ex).getSQLState())) {
                    response.sendRedirect(context + "/register.jsp?error=duplicate");
                } else {
                    getServletContext().log("Student registration failed", ex);
                    response.sendRedirect(context + "/register.jsp?error=unavailable");
                }
            } finally {
                connection.setAutoCommit(true);
            }
        } catch (SQLException ex) {
            getServletContext().log("Student registration could not connect to database", ex);
            response.sendRedirect(context + "/register.jsp?error=unavailable");
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.sendRedirect(request.getContextPath() + "/register.jsp");
    }

    private static String value(String value) { return value == null ? "" : value.trim(); }
}
