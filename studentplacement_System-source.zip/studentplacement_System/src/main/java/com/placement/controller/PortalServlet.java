package com.placement.controller;

import com.placement.dao.DatabaseConnection;
import com.placement.security.PasswordHasher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.*;
import java.nio.file.*;
import java.security.GeneralSecurityException;
import java.sql.*;
import java.time.Year;
import java.util.*;

/** Database-backed workflows for the placement portal. */
@WebServlet("/PortalServlet")
@MultipartConfig(maxFileSize=5242880, maxRequestSize=6291456)
public class PortalServlet extends HttpServlet {
    private static final String[] RESUME_EXT = {"pdf", "doc", "docx"};
    private String context(HttpServletRequest r) { return r.getContextPath(); }
    private String role(HttpServletRequest r) { return (String) r.getSession().getAttribute("userRole"); }
    private long uid(HttpServletRequest r) { Object x=r.getSession().getAttribute("userId"); return x instanceof Number ? ((Number)x).longValue() : -1; }
    private boolean require(HttpServletRequest r,HttpServletResponse s,String wanted)throws IOException {
        if(uid(r)<0 || (wanted!=null && !wanted.equals(role(r)))) { s.sendRedirect(context(r)+"/index.jsp?error=invalid"); return false; } return true;
    }
    private static String val(String x){return x==null?"":x.trim();}
    private static String esc(String x){return x==null?"":x;}
    private static List<Map<String,Object>> rows(Connection c,String sql,Object... args)throws SQLException{
        List<Map<String,Object>> out=new ArrayList<>(); try(PreparedStatement p=c.prepareStatement(sql)){for(int i=0;i<args.length;i++)p.setObject(i+1,args[i]);try(ResultSet r=p.executeQuery()){ResultSetMetaData m=r.getMetaData();while(r.next()){Map<String,Object> row=new LinkedHashMap<>();for(int i=1;i<=m.getColumnCount();i++)row.put(m.getColumnLabel(i),r.getObject(i));out.add(row);}}}return out;
    }
    private static long count(Connection c,String sql,Object...args)throws SQLException{try(PreparedStatement p=c.prepareStatement(sql)){for(int i=0;i<args.length;i++)p.setObject(i+1,args[i]);try(ResultSet r=p.executeQuery()){r.next();return r.getLong(1);}}}
    @Override protected void doGet(HttpServletRequest req,HttpServletResponse resp)throws ServletException,IOException{
        String r=role(req), action=val(req.getParameter("action"));
        if("recruiter-register".equals(action)){req.getRequestDispatcher("/recruiter-register.jsp").forward(req,resp);return;}
        if(uid(req)<0){resp.sendRedirect(context(req)+"/index.jsp");return;}
        if("report".equals(action)){if(!require(req,resp,"admin"))return;try{downloadReport(resp);}catch(SQLException ex){getServletContext().log("Could not generate placement report",ex);resp.sendError(500);}return;}
        try(Connection c=DatabaseConnection.initializeDatabase()){
            if("view-resume".equals(action)){if(!"recruiter".equals(r)&&!"admin".equals(r)){resp.sendError(403);return;}viewResume(req,resp,c);return;}
            if("company-logo".equals(action)){serveCompanyLogo(req,resp,c);return;}
            if("company-profile".equals(action)){ensureRecruiterProfileColumns(c);long companyId=Long.parseLong(req.getParameter("recruiterId"));List<Map<String,Object>> company=rows(c,"SELECT r.*,u.full_name FROM recruiters r JOIN users u ON u.id=r.user_id WHERE r.user_id=? AND u.status='active'",companyId);if(company.isEmpty()){resp.sendError(404);return;}req.setAttribute("companyProfile",company.get(0));List<Map<String,Object>> companyJobs=rows(c,"SELECT * FROM jobs WHERE recruiter_user_id=? AND status='approved' AND (application_deadline IS NULL OR application_deadline>=CURRENT_DATE) ORDER BY created_at DESC",companyId);for(Map<String,Object> job:companyJobs)job.put("descriptionSections",descriptionSections(String.valueOf(job.get("description"))));req.setAttribute("companyJobs",companyJobs);req.getRequestDispatcher("/company-profile.jsp").forward(req,resp);return;}
            if("student".equals(r)){
                ensureRecruiterProfileColumns(c);
                List<Map<String,Object>> studentJobs=rows(c,"SELECT j.*,r.company_name,r.user_id recruiter_user_id,r.logo_path FROM jobs j JOIN recruiters r ON r.user_id=j.recruiter_user_id JOIN users u ON u.id=r.user_id WHERE j.status='approved' AND u.status='active' AND (j.application_deadline IS NULL OR j.application_deadline>=CURRENT_DATE) ORDER BY j.created_at DESC");
                for(Map<String,Object> job:studentJobs)job.put("descriptionSections",descriptionSections(String.valueOf(job.get("description"))));
                req.setAttribute("applications",rows(c,"SELECT a.id,a.status,a.applied_at,j.title,r.company_name FROM applications a JOIN jobs j ON j.id=a.job_id JOIN recruiters r ON r.user_id=j.recruiter_user_id WHERE a.student_user_id=? ORDER BY a.updated_at DESC",uid(req)));
                List<Map<String,Object>> profile=rows(c,"SELECT s.*,u.email,u.full_name FROM students s JOIN users u ON u.id=s.user_id WHERE s.user_id=?",uid(req));
                if(!profile.isEmpty())req.setAttribute("profile",profile.get(0));
                List<Map<String,Object>> preferenceRows=rows(c,"SELECT * FROM student_preferences WHERE student_user_id=?",uid(req));
                if(preferenceRows.isEmpty() || !Boolean.TRUE.equals(preferenceRows.get(0).get("onboarding_complete")) && !"1".equals(String.valueOf(preferenceRows.get(0).get("onboarding_complete")))){
                    req.setAttribute("preferences", Collections.emptyMap());
                    req.getRequestDispatcher("/student-onboarding.jsp").forward(req,resp);return;
                }
                Map<String,Object> preferences=preferenceRows.get(0);
                req.setAttribute("preferences",preferences);
                if("resume-step".equals(action)){req.getRequestDispatcher("/student-resume-step.jsp").forward(req,resp);return;}
                if("edit-preferences".equals(action)){req.getRequestDispatcher("/student-onboarding.jsp").forward(req,resp);return;}
                final String preferredType=String.valueOf(preferences.get("employment_type"));
                final String preferredRole=String.valueOf(preferences.get("preferred_role")).toLowerCase(Locale.ROOT);
                studentJobs.sort((a,b)->Integer.compare(jobPreferenceScore(b,preferredType,preferredRole),jobPreferenceScore(a,preferredType,preferredRole)));
                req.setAttribute("jobs",studentJobs);
                req.getRequestDispatcher("/student-dashboard.jsp").forward(req,resp);
            } else if("recruiter".equals(r)){
                ensureRecruiterProfileColumns(c);
                req.setAttribute("companyProfile",rows(c,"SELECT r.*,u.full_name,u.email,u.status account_status FROM recruiters r JOIN users u ON u.id=r.user_id WHERE r.user_id=?",uid(req)).get(0));
                if("recruiter-profile".equals(action)){req.getRequestDispatcher("/recruiter-profile.jsp").forward(req,resp);return;}
                req.setAttribute("jobs",rows(c,"SELECT j.*, (SELECT COUNT(*) FROM applications a WHERE a.job_id=j.id) applicants FROM jobs j WHERE j.recruiter_user_id=? ORDER BY j.created_at DESC",uid(req)));
                req.setAttribute("applications",rows(c,"SELECT a.id,a.status,a.applied_at,j.title,u.full_name,u.email,s.program,s.graduation_year,s.gpa,s.resume_path,j.id job_id FROM applications a JOIN jobs j ON j.id=a.job_id JOIN students s ON s.user_id=a.student_user_id JOIN users u ON u.id=s.user_id WHERE j.recruiter_user_id=? ORDER BY a.updated_at DESC",uid(req)));
                req.setAttribute("jobCount",count(c,"SELECT COUNT(*) FROM jobs WHERE recruiter_user_id=?",uid(req)));
                req.setAttribute("accountStatus",rows(c,"SELECT status FROM users WHERE id=?",uid(req)).get(0).get("status"));
                req.getRequestDispatcher("/recruiter-dashboard.jsp").forward(req,resp);
            } else if("admin".equals(r)){
                req.setAttribute("pendingRecruiters",rows(c,"SELECT u.id,u.full_name,u.email,r.company_name,r.company_website FROM users u JOIN recruiters r ON r.user_id=u.id WHERE u.status='pending' ORDER BY u.created_at"));
                req.setAttribute("pendingJobs",rows(c,"SELECT j.id,j.title,j.location,j.employment_type,j.created_at,r.company_name,u.full_name FROM jobs j JOIN recruiters r ON r.user_id=j.recruiter_user_id JOIN users u ON u.id=r.user_id WHERE j.status='pending' ORDER BY j.created_at"));
                req.setAttribute("stats",Map.of("students",count(c,"SELECT COUNT(*) FROM students"),"placed",count(c,"SELECT COUNT(DISTINCT student_user_id) FROM applications WHERE status='offered'"),"recruiters",count(c,"SELECT COUNT(*) FROM users WHERE role='recruiter' AND status='active'"),"jobs",count(c,"SELECT COUNT(*) FROM jobs WHERE status='approved'"),"applications",count(c,"SELECT COUNT(*) FROM applications")));
                req.setAttribute("report",rows(c,"SELECT r.company_name,COUNT(DISTINCT a.student_user_id) placed,COUNT(a.id) applications FROM recruiters r JOIN jobs j ON j.recruiter_user_id=r.user_id LEFT JOIN applications a ON a.job_id=j.id AND a.status='offered' WHERE j.status='approved' GROUP BY r.user_id,r.company_name ORDER BY placed DESC"));
                req.getRequestDispatcher("/admin-dashboard.jsp").forward(req,resp);
            } else {resp.sendRedirect(context(req)+"/index.jsp");}
        }catch(SQLException ex){getServletContext().log("Could not load placement workspace",ex);resp.sendRedirect(context(req)+"/index.jsp?error=unavailable");}
    }
    @Override protected void doPost(HttpServletRequest req,HttpServletResponse resp)throws ServletException,IOException{
        req.setCharacterEncoding("UTF-8");String action=val(req.getParameter("action")),r=role(req);String dest="/PortalServlet";
        try(Connection c=DatabaseConnection.initializeDatabase()){
            switch(action){
                case "recruiter-register": registerRecruiter(req,resp,c);return;
                case "apply": if(!require(req,resp,"student"))return; apply(req,c);dest="/PortalServlet?message=applied";break;
                case "profile": if(!require(req,resp,"student"))return; updateProfile(req,c);dest="/PortalServlet?message=profile";break;
                case "preferences": if(!require(req,resp,"student"))return; savePreferences(req,c);dest="/PortalServlet?action=resume-step";break;
                case "resume": if(!require(req,resp,"student"))return; uploadResume(req,c);dest="/PortalServlet?message=resume";break;
                case "resume-continue": if(!require(req,resp,"student"))return; Part resumePart=req.getPart("resume");if(resumePart!=null&&resumePart.getSize()>0)storeResume(resumePart,c,uid(req));dest="/PortalServlet?message=onboarding-complete";break;
                case "recruiter-profile": if(!require(req,resp,"recruiter"))return; ensureRecruiterProfileColumns(c);saveRecruiterProfile(req,c);dest="/PortalServlet?action=recruiter-profile&message=profile";break;
                case "post-job": if(!require(req,resp,"recruiter"))return; postJob(req,c);dest="/PortalServlet?message=job";break;
                case "application-status": if(!require(req,resp,"recruiter"))return; updateApplication(req,c,uid(req));dest="/PortalServlet?message=status";break;
                case "approve-recruiter": if(!require(req,resp,"admin"))return; approveRecruiter(req,c);dest="/PortalServlet?message=approved";break;
                case "approve-job": if(!require(req,resp,"admin"))return; approveJob(req,c);dest="/PortalServlet?message=approved";break;
                case "download-resume": if(!"recruiter".equals(r)&&!"admin".equals(r)){resp.sendError(403);return;} downloadResume(req,resp,c,false);return;
                default: resp.sendError(400);return;
            }
        }catch(IllegalArgumentException ex){dest="/PortalServlet?error=invalid";}catch(SQLException ex){getServletContext().log("Placement operation failed: "+action,ex);dest="/PortalServlet?error=operation";}catch(GeneralSecurityException ex){getServletContext().log("Could not secure recruiter password",ex);dest="/recruiter-register.jsp?error=unavailable";}
        resp.sendRedirect(context(req)+dest);
    }
    private static List<Map<String,String>> descriptionSections(String raw){
        List<Map<String,String>> sections=new ArrayList<>();String text=raw==null?"":raw.trim();
        String[] keys={"OVERVIEW","RESPONSIBILITIES","REQUIREMENTS","SKILLS","BENEFITS"};
        if(!text.startsWith("[[CHS_JOB_V1]]")){
            java.util.regex.Pattern heading=java.util.regex.Pattern.compile("(?i)(overview|role overview|responsibilities|duties|requirements|qualifications|skills|benefits)\\s*:");
            java.util.regex.Matcher matcher=heading.matcher(text);List<Integer> starts=new ArrayList<>();List<String> titles=new ArrayList<>();
            while(matcher.find()){starts.add(matcher.start());titles.add(matcher.group(1));}
            if(!starts.isEmpty()){
                if(starts.get(0)>0)addDescriptionSection(sections,"Overview",text.substring(0,starts.get(0)));
                for(int i=0;i<starts.size();i++){int bodyStart=text.indexOf(':',starts.get(i))+1;int bodyEnd=i+1<starts.size()?starts.get(i+1):text.length();addDescriptionSection(sections,titles.get(i),text.substring(bodyStart,bodyEnd));}
            }else{
                String normalized=text.replaceAll("\\r\\n?","\\n").trim();String[] paragraphs=normalized.split("\\n\\s*\\n");
                if(paragraphs.length>1){for(int i=0;i<paragraphs.length;i++)addDescriptionSection(sections,i==0?"Overview":"Additional details",paragraphs[i]);}
                else {String[] sentences=normalized.split("(?<=[.!?])\\s+(?=[A-Z0-9])");StringBuilder group=new StringBuilder();for(int i=0;i<sentences.length;i++){if(group.length()>0)group.append(' ');group.append(sentences[i]);if((i+1)%2==0||i==sentences.length-1){addDescriptionSection(sections,i<2?"Overview":"Role details",group.toString());group.setLength(0);}}}
            }
            return sections;
        }
        for(String key:keys){String marker="[["+key+"]]";int start=text.indexOf(marker);if(start<0)continue;start+=marker.length();while(start<text.length()&&(text.charAt(start)=='\n'||text.charAt(start)=='\r'))start++;int end=text.length();for(String next:keys){int pos=text.indexOf("[["+next+"]]",start);if(pos>=0&&pos<end)end=pos;}addDescriptionSection(sections,key.substring(0,1)+key.substring(1).toLowerCase(Locale.ROOT),text.substring(start,end));}
        return sections;
    }
    private static void addDescriptionSection(List<Map<String,String>> out,String title,String body){String clean=body==null?"":body.trim();if(clean.isEmpty())return;Map<String,String> section=new LinkedHashMap<>();section.put("title",title);section.put("body",clean);out.add(section);}
    private void ensureRecruiterProfileColumns(Connection c)throws SQLException{
        String[][] columns={{"company_description","TEXT NULL"},{"industry","VARCHAR(120) NULL"},{"company_location","VARCHAR(160) NULL"},{"company_size","VARCHAR(80) NULL"},{"logo_path","VARCHAR(120) NULL"}};
        for(String[] column:columns){boolean found=false;try(ResultSet r=c.getMetaData().getColumns(c.getCatalog(),null,"recruiters",column[0])){found=r.next();}if(!found)try(Statement st=c.createStatement()){st.executeUpdate("ALTER TABLE recruiters ADD COLUMN "+column[0]+" "+column[1]);}}
    }
    private void saveRecruiterProfile(HttpServletRequest q,Connection c)throws SQLException,IOException,ServletException{
        String company=val(q.getParameter("companyName")),website=val(q.getParameter("website")),phone=val(q.getParameter("phone")),description=val(q.getParameter("companyDescription")),industry=val(q.getParameter("industry")),location=val(q.getParameter("companyLocation")),size=val(q.getParameter("companySize"));
        if(company.length()<2||company.length()>160||website.length()>255||phone.length()>30||description.length()>3000||industry.length()>120||location.length()>160||size.length()>80)throw new IllegalArgumentException();
        String logo=null;Part part=q.getPart("companyLogo");if(part!=null&&part.getSize()>0)logo=storeCompanyLogo(part);
        String sql="UPDATE recruiters SET company_name=?,company_website=?,contact_phone=?,company_description=?,industry=?,company_location=?,company_size=?"+(logo==null?"":" ,logo_path=?")+" WHERE user_id=?";
        try(PreparedStatement p=c.prepareStatement(sql)){int i=1;p.setString(i++,company);p.setString(i++,website.isEmpty()?null:website);p.setString(i++,phone.isEmpty()?null:phone);p.setString(i++,description.isEmpty()?null:description);p.setString(i++,industry.isEmpty()?null:industry);p.setString(i++,location.isEmpty()?null:location);p.setString(i++,size.isEmpty()?null:size);if(logo!=null)p.setString(i++,logo);p.setLong(i,uid(q));p.executeUpdate();}
    }
    private String storeCompanyLogo(Part part)throws IOException{if(part.getSize()>2097152)throw new IllegalArgumentException();String original=Paths.get(part.getSubmittedFileName()==null?"logo":part.getSubmittedFileName()).getFileName().toString();String ext=original.contains(".")?original.substring(original.lastIndexOf('.')+1).toLowerCase(Locale.ROOT):"";if(!Arrays.asList("png","jpg","jpeg","webp").contains(ext))throw new IllegalArgumentException();String mime=part.getContentType();if(mime!=null&&!Arrays.asList("image/png","image/jpeg","image/webp","application/octet-stream").contains(mime))throw new IllegalArgumentException();Path dir=Paths.get(System.getProperty("user.home"),"Documents","Codex","placement-uploads");Files.createDirectories(dir);String filename=UUID.randomUUID()+"."+ext;part.write(dir.resolve(filename).toString());return filename;}
    private void serveCompanyLogo(HttpServletRequest q,HttpServletResponse s,Connection c)throws SQLException,IOException{long id=Long.parseLong(q.getParameter("recruiterId"));String file=null;String sql="SELECT r.logo_path FROM recruiters r JOIN users u ON u.id=r.user_id WHERE r.user_id=? AND ((?='recruiter' AND r.user_id=?) OR (u.status='active' AND EXISTS(SELECT 1 FROM jobs j WHERE j.recruiter_user_id=r.user_id AND j.status='approved')))";try(PreparedStatement p=c.prepareStatement(sql)){p.setLong(1,id);p.setString(2,role(q)==null?"":role(q));p.setLong(3,uid(q));try(ResultSet r=p.executeQuery()){if(r.next())file=r.getString(1);}}if(file==null||!file.matches("[a-f0-9-]+\\.(png|jpg|jpeg|webp)")){s.sendError(404);return;}Path path=Paths.get(System.getProperty("user.home"),"Documents","Codex","placement-uploads",file);if(!Files.isRegularFile(path)){s.sendError(404);return;}String ext=file.substring(file.lastIndexOf('.')+1);s.setContentType("image/"+("jpg".equals(ext)?"jpeg":ext));s.setHeader("Cache-Control","public, max-age=3600");Files.copy(path,s.getOutputStream());}
    private void viewResume(HttpServletRequest q,HttpServletResponse s,Connection c)throws SQLException,IOException{downloadResume(q,s,c,true);}
    private static int jobPreferenceScore(Map<String,Object> job,String type,String preferredRole){
        int score=0;String jobType=String.valueOf(job.get("employment_type"));
        if(!"any".equals(type)&&type.equals(jobType))score+=4;
        String title=String.valueOf(job.get("title")).toLowerCase(Locale.ROOT);
        if(!preferredRole.isEmpty()&&(title.contains(preferredRole)||preferredRole.contains(title)))score+=3;
        return score;
    }
    private void savePreferences(HttpServletRequest q,Connection c)throws SQLException{
        String work=val(q.getParameter("workStyle")),strength=val(q.getParameter("strength")),environment=val(q.getParameter("environment")),jobRole=val(q.getParameter("preferredRole")),industry=val(q.getParameter("industry")),type=val(q.getParameter("employmentType")),mode=val(q.getParameter("workMode"));
        if(!Arrays.asList("team","independent","balanced").contains(work)||!Arrays.asList("problem_solving","communication","creative","organizing").contains(strength)||!Arrays.asList("structured","fast_paced","flexible").contains(environment)||jobRole.length()<2||jobRole.length()>120||industry.length()>100||!Arrays.asList("any","full-time","part-time","internship").contains(type)||!Arrays.asList("any","remote","hybrid","onsite").contains(mode))throw new IllegalArgumentException();
        String sql="INSERT INTO student_preferences(student_user_id,work_style,strength,environment,preferred_role,preferred_industry,employment_type,work_mode,onboarding_complete) VALUES(?,?,?,?,?,?,?,?,TRUE) ON DUPLICATE KEY UPDATE work_style=VALUES(work_style),strength=VALUES(strength),environment=VALUES(environment),preferred_role=VALUES(preferred_role),preferred_industry=VALUES(preferred_industry),employment_type=VALUES(employment_type),work_mode=VALUES(work_mode),onboarding_complete=TRUE";
        try(PreparedStatement p=c.prepareStatement(sql)){p.setLong(1,uid(q));p.setString(2,work);p.setString(3,strength);p.setString(4,environment);p.setString(5,jobRole);p.setString(6,industry.isEmpty()?null:industry);p.setString(7,type);p.setString(8,mode);p.executeUpdate();}
    }
    private void registerRecruiter(HttpServletRequest q,HttpServletResponse s,Connection c)throws IOException,SQLException,GeneralSecurityException{
        String name=val(q.getParameter("fullName")),email=val(q.getParameter("email")).toLowerCase(Locale.ROOT),company=val(q.getParameter("companyName")),website=val(q.getParameter("website")),phone=val(q.getParameter("phone")),pw=q.getParameter("password");
        if(name.length()<2||email.isEmpty()||company.length()<2||pw==null||pw.length()<10||!email.matches("^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$"))throw new IllegalArgumentException();
        c.setAutoCommit(false);try{long id;try(PreparedStatement p=c.prepareStatement("INSERT INTO users(full_name,email,password_hash,role,status) VALUES(?,?,?,'recruiter','pending')",Statement.RETURN_GENERATED_KEYS)){p.setString(1,name);p.setString(2,email);p.setString(3,PasswordHasher.hash(pw.toCharArray()));p.executeUpdate();try(ResultSet k=p.getGeneratedKeys()){k.next();id=k.getLong(1);}}try(PreparedStatement p=c.prepareStatement("INSERT INTO recruiters(user_id,company_name,company_website,contact_phone) VALUES(?,?,?,?)")){p.setLong(1,id);p.setString(2,company);p.setString(3,website);p.setString(4,phone);p.executeUpdate();}c.commit();s.sendRedirect(q.getContextPath()+"/index.jsp?registered=1");}catch(SQLException|GeneralSecurityException ex){c.rollback();if(ex instanceof SQLException&&"23000".equals(((SQLException)ex).getSQLState()))s.sendRedirect(q.getContextPath()+"/recruiter-register.jsp?error=duplicate");else throw ex;}finally{c.setAutoCommit(true);}
    }
    private void apply(HttpServletRequest q,Connection c)throws SQLException{long job=Long.parseLong(q.getParameter("jobId"));try(PreparedStatement p=c.prepareStatement("INSERT INTO applications(job_id,student_user_id) SELECT j.id,? FROM jobs j JOIN users ru ON ru.id=j.recruiter_user_id AND ru.status='active' WHERE j.id=? AND j.status='approved' AND (j.application_deadline IS NULL OR j.application_deadline>=CURRENT_DATE) AND (j.minimum_gpa IS NULL OR j.minimum_gpa <= COALESCE((SELECT gpa FROM students WHERE user_id=?),0)) AND (j.graduation_year IS NULL OR j.graduation_year=(SELECT graduation_year FROM students WHERE user_id=?))")){p.setLong(1,uid(q));p.setLong(2,job);p.setLong(3,uid(q));p.setLong(4,uid(q));if(p.executeUpdate()!=1)throw new IllegalArgumentException();}}
    private void updateProfile(HttpServletRequest q,Connection c)throws SQLException{String phone=val(q.getParameter("phone")),gpa=val(q.getParameter("gpa")),summary=val(q.getParameter("summary"));Double g=null;if(!gpa.isEmpty()){g=Double.valueOf(gpa);if(g<0||g>10)throw new IllegalArgumentException();}try(PreparedStatement p=c.prepareStatement("UPDATE students SET phone=?,gpa=?,profile_summary=? WHERE user_id=?")){p.setString(1,phone);if(g==null)p.setNull(2,Types.DECIMAL);else p.setDouble(2,g);p.setString(3,summary);p.setLong(4,uid(q));p.executeUpdate();}}
    private void uploadResume(HttpServletRequest q,Connection c)throws IOException,ServletException,SQLException{storeResume(q.getPart("resume"),c,uid(q));}
    private void storeResume(Part part,Connection c,long studentId)throws IOException,SQLException{if(part==null||part.getSize()<1||part.getSize()>5242880)throw new IllegalArgumentException();String original=Paths.get(part.getSubmittedFileName()==null?"resume":part.getSubmittedFileName()).getFileName().toString();String ext=original.contains(".")?original.substring(original.lastIndexOf('.')+1).toLowerCase(Locale.ROOT):"";if(!Arrays.asList(RESUME_EXT).contains(ext))throw new IllegalArgumentException();String mime=part.getContentType();if(mime!=null&&!Arrays.asList("application/pdf","application/msword","application/vnd.openxmlformats-officedocument.wordprocessingml.document","application/octet-stream").contains(mime))throw new IllegalArgumentException();Path dir=Paths.get(System.getProperty("user.home"),"Documents","Codex","placement-uploads");Files.createDirectories(dir);String filename=UUID.randomUUID()+"."+ext;part.write(dir.resolve(filename).toString());try(PreparedStatement p=c.prepareStatement("UPDATE students SET resume_path=? WHERE user_id=?")){p.setString(1,filename);p.setLong(2,studentId);p.executeUpdate();}}
    private void postJob(HttpServletRequest q,Connection c)throws SQLException{
        String title=val(q.getParameter("title")),loc=val(q.getParameter("location")),type=val(q.getParameter("employmentType"));
        String overview=val(q.getParameter("overview")),responsibilities=val(q.getParameter("responsibilities")),requirements=val(q.getParameter("requirements")),skills=val(q.getParameter("requiredSkills")),benefits=val(q.getParameter("benefits"));
        String desc;
        if(!overview.isEmpty()||!responsibilities.isEmpty()||!requirements.isEmpty()||!skills.isEmpty()||!benefits.isEmpty()){
            if(overview.isEmpty()||responsibilities.isEmpty()||requirements.isEmpty()||overview.length()>2000||responsibilities.length()>2500||requirements.length()>2500||skills.length()>1200||benefits.length()>1500)throw new IllegalArgumentException();
            desc="[[CHS_JOB_V1]]\n[[OVERVIEW]]\n"+overview+"\n[[RESPONSIBILITIES]]\n"+responsibilities+"\n[[REQUIREMENTS]]\n"+requirements+"\n[[SKILLS]]\n"+skills+"\n[[BENEFITS]]\n"+benefits;
        }else{desc=val(q.getParameter("description"));}
        if(title.isEmpty()||title.length()>160||loc.isEmpty()||loc.length()>160||desc.isEmpty()||desc.length()>8000||!Arrays.asList("internship","full-time","part-time","contract").contains(type))throw new IllegalArgumentException();
        Double gpa=null;String g=val(q.getParameter("minimumGpa"));if(!g.isEmpty()){gpa=Double.valueOf(g);if(gpa<0||gpa>10)throw new IllegalArgumentException();}
        Integer year=null;String y=val(q.getParameter("graduationYear"));if(!y.isEmpty()){year=Integer.valueOf(y);if(year<Year.now().getValue()||year>Year.now().getValue()+8)throw new IllegalArgumentException();}
        c.setAutoCommit(false);try{
            try(PreparedStatement lock=c.prepareStatement("SELECT id,status FROM users WHERE id=? FOR UPDATE")){lock.setLong(1,uid(q));try(ResultSet rs=lock.executeQuery()){if(!rs.next()||!"active".equals(rs.getString("status")))throw new IllegalArgumentException();}}
            if(count(c,"SELECT COUNT(*) FROM jobs WHERE recruiter_user_id=?",uid(q))>=10)throw new IllegalArgumentException();
            try(PreparedStatement p=c.prepareStatement("INSERT INTO jobs(recruiter_user_id,title,description,location,employment_type,minimum_gpa,graduation_year,application_deadline) VALUES(?,?,?,?,?,?,?,?)")){p.setLong(1,uid(q));p.setString(2,title);p.setString(3,desc);p.setString(4,loc);p.setString(5,type);if(gpa==null)p.setNull(6,Types.DECIMAL);else p.setDouble(6,gpa);if(year==null)p.setNull(7,Types.SMALLINT);else p.setInt(7,year);String d=val(q.getParameter("deadline"));if(d.isEmpty())p.setNull(8,Types.DATE);else p.setDate(8,java.sql.Date.valueOf(d));p.executeUpdate();}
            c.commit();
        }catch(SQLException|IllegalArgumentException ex){c.rollback();throw ex;}finally{c.setAutoCommit(true);}
    }
    private void updateApplication(HttpServletRequest q,Connection c,long recruiter)throws SQLException{String status=val(q.getParameter("status"));if(!Arrays.asList("under_review","shortlisted","interview","offered","rejected").contains(status))throw new IllegalArgumentException();try(PreparedStatement p=c.prepareStatement("UPDATE applications a JOIN jobs j ON j.id=a.job_id SET a.status=? WHERE a.id=? AND j.recruiter_user_id=?")){p.setString(1,status);p.setLong(2,Long.parseLong(q.getParameter("applicationId")));p.setLong(3,recruiter);if(p.executeUpdate()!=1)throw new IllegalArgumentException();}}
    private void approveRecruiter(HttpServletRequest q,Connection c)throws SQLException{long id=Long.parseLong(q.getParameter("id"));String v=val(q.getParameter("decision"));String status="approve".equals(v)?"active":"rejected";try(PreparedStatement p=c.prepareStatement("UPDATE users SET status=? WHERE id=? AND role='recruiter' AND status='pending'")){p.setString(1,status);p.setLong(2,id);if(p.executeUpdate()!=1)throw new IllegalArgumentException();}if("active".equals(status))try(PreparedStatement p=c.prepareStatement("UPDATE recruiters SET approved_at=CURRENT_TIMESTAMP WHERE user_id=?")){p.setLong(1,id);p.executeUpdate();}}
    private void approveJob(HttpServletRequest q,Connection c)throws SQLException{long id=Long.parseLong(q.getParameter("id"));String status="approve".equals(q.getParameter("decision"))?"approved":"rejected";try(PreparedStatement p=c.prepareStatement("UPDATE jobs SET status=? WHERE id=? AND status='pending'")){p.setString(1,status);p.setLong(2,id);if(p.executeUpdate()!=1)throw new IllegalArgumentException();}}
    private void downloadResume(HttpServletRequest q,HttpServletResponse s,Connection c,boolean inline)throws SQLException,IOException{long app=Long.parseLong(q.getParameter("applicationId"));String sql="SELECT s.resume_path FROM applications a JOIN students s ON s.user_id=a.student_user_id JOIN jobs j ON j.id=a.job_id WHERE a.id=? AND (j.recruiter_user_id=? OR ?=1)";String f=null;try(PreparedStatement p=c.prepareStatement(sql)){p.setLong(1,app);p.setLong(2,uid(q));p.setInt(3,"admin".equals(role(q))?1:0);try(ResultSet r=p.executeQuery()){if(r.next())f=r.getString(1);}}if(f==null||!f.matches("[a-f0-9-]+\\.(pdf|doc|docx)")){s.sendError(404);return;}Path path=Paths.get(System.getProperty("user.home"),"Documents","Codex","placement-uploads",f);if(!Files.isRegularFile(path)){s.sendError(404);return;}String ext=f.substring(f.lastIndexOf('.')+1);s.setContentType("pdf".equals(ext)?"application/pdf":"application/octet-stream");s.setHeader("Content-Disposition",(inline&&"pdf".equals(ext)?"inline":"attachment")+"; filename=\"student-resume."+ext+"\"");Files.copy(path,s.getOutputStream());}
    private void downloadReport(HttpServletResponse response)throws IOException,SQLException{response.setContentType("text/csv;charset=UTF-8");response.setHeader("Content-Disposition","attachment; filename=\"chs-placement-report.csv\"");try(Connection c=DatabaseConnection.initializeDatabase();PrintWriter w=response.getWriter()){w.println("Company,Applications,Offers");for(Map<String,Object>r:rows(c,"SELECT r.company_name,COUNT(a.id) applications,COUNT(DISTINCT CASE WHEN a.status='offered' THEN a.student_user_id END) placed FROM recruiters r JOIN jobs j ON j.recruiter_user_id=r.user_id LEFT JOIN applications a ON a.job_id=j.id WHERE j.status='approved' GROUP BY r.user_id,r.company_name ORDER BY r.company_name")){String company=String.valueOf(r.get("company_name")).replace("\"","\"\"");w.printf("\"%s\",%s,%s%n",company,r.get("applications"),r.get("placed"));}}}
}
