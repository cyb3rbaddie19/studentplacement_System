<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%
    String context = request.getContextPath();
    String error = request.getParameter("error");
%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="theme-color" content="#102d27">
    <title>Sign in | Chetana Hazrimal Somani College Placement Management System</title><link rel="stylesheet" href="<%= context %>/css/enterprise.css?v=chs20261013">
</head>
<body class="auth-page">
<main class="auth-layout">
    <section class="auth-story" aria-label="College placement portal introduction"><img class="auth-campus-photo" src="<%=context%>/images/campus-login.png" alt="">
        <a class="brand brand-light" href="<%= context %>/index.jsp" aria-label="College placement portal home"><img src="<%=context%>/images/college-emblem.png" width="45" height="45" alt="CHS College logo"><span class="brand-copy"><strong>CHS College</strong><small>CAREERS & PLACEMENTS</small></span></a>
        <div class="story-content"><span class="eyebrow eyebrow-light"><span class="live-dot"></span> YOUR NEXT CHAPTER STARTS HERE</span><h1>Make your<br><em>ambition</em> matter.</h1><p>One place to discover opportunities, build your profile, and move confidently from campus to career.</p><div class="story-proof"><div class="avatar-stack"><span>AS</span><span>RK</span><span>PM</span><b>+</b></div><span><strong>Built around your future</strong><small>Students · Recruiters · Placement team</small></span></div></div>
            <div class="story-foot"><span>CHETANA HAZRIMAL SOMANI COLLEGE</span><span>PLACEMENT MANAGEMENT SYSTEM</span></div><div class="story-orb orb-one"></div><div class="story-orb orb-two"></div>
    </section>
    <section class="auth-panel"><div class="auth-mobile-brand brand"><img src="<%=context%>/images/college-emblem.png" width="45" height="45" alt="CHS College logo"><span class="brand-copy"><strong>CHS College</strong><small>CAREERS & PLACEMENTS</small></span></div>
        <div class="auth-form-wrap"><div class="form-heading"><span class="eyebrow">WELCOME BACK</span><h2>Sign in to your account</h2><p>Enter your college or work email to continue.</p></div>
            <% if ("1".equals(request.getParameter("registered"))) { %><div class="alert alert-success" role="status">Your account is ready. Sign in to continue.</div><% } else if ("unavailable".equals(error)) { %><div class="alert alert-error" role="alert">We could not reach the placement database. Please contact the placement office.</div><% } else if ("invalid".equals(error)) { %><div class="alert alert-error" role="alert">We couldn't sign you in. Check your details and try again.</div><% } else if ("unsupported_role".equals(error)) { %><div class="alert alert-error" role="alert">This portal isn't available yet. Please choose Student to continue.</div><% } %>
            <form action="<%= context %>/LoginServlet" method="post" class="auth-form">
                <label for="email">Email address</label><div class="field-wrap"><span class="field-icon" aria-hidden="true">✉</span><input id="email" type="email" name="email" placeholder="you@college.edu" autocomplete="username" required></div>
                <div class="label-row"><label for="password">Password</label><a href="#help" class="text-link" title="Contact your placement administrator">Need help?</a></div><div class="field-wrap"><span class="field-icon" aria-hidden="true">⌑</span><input id="password" type="password" name="password" placeholder="Enter your password" autocomplete="current-password" required><button class="password-toggle" type="button" aria-label="Show password" data-password-toggle>Show</button></div>
                <label for="role">Continue as</label><div class="field-wrap select-wrap"><span class="field-icon" aria-hidden="true">◎</span><select id="role" name="role" required><option value="student">Student</option><option value="recruiter">Recruiter</option><option value="admin">Placement administrator</option></select><span class="select-chevron" aria-hidden="true">⌄</span></div>
                <div class="form-options"><label class="check-label"><input type="checkbox" name="remember" value="yes"><span>Remember me</span></label><span class="secure-note"><span aria-hidden="true">▣</span> Secure sign in</span></div><button type="submit" class="btn-primary btn-block">Sign in <span aria-hidden="true">→</span></button>
            </form>
            <div class="auth-divider"><span>NEW TO THE PORTAL?</span></div><a class="btn-secondary btn-block" href="<%= context %>/register.jsp">Create a student account <span aria-hidden="true">↗</span></a><p class="auth-help">Recruiter? <a href="<%=context%>/recruiter-login.jsp">Recruiter sign in</a> · <a href="<%=context%>/PortalServlet?action=recruiter-register">Create employer account</a></p><p class="auth-help" id="help">Having trouble signing in? <a href="mailto:placements@chscollege.edu">Contact the placement office</a></p>
        </div><footer class="auth-footer"><span>© 2026 Chetana Hazrimal Somani College</span><a href="#privacy">Privacy</a><a href="#support">Support</a></footer>
    </section>
</main>
<script>document.querySelector('[data-password-toggle]').addEventListener('click',function(){const input=document.getElementById('password');const showing=input.type==='text';input.type=showing?'password':'text';this.textContent=showing?'Show':'Hide';this.setAttribute('aria-label',showing?'Show password':'Hide password');});</script>
</body></html>



