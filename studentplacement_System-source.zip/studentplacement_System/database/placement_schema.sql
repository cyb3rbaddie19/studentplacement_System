CREATE DATABASE IF NOT EXISTS chs_placement_portal
  CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;
USE chs_placement_portal;

CREATE TABLE IF NOT EXISTS users (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(120) NOT NULL,
    email VARCHAR(190) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('student', 'recruiter', 'admin') NOT NULL DEFAULT 'student',
    status ENUM('pending', 'active', 'rejected') NOT NULL DEFAULT 'active',
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS students (
    user_id BIGINT UNSIGNED NOT NULL PRIMARY KEY,
    student_number VARCHAR(40) NOT NULL UNIQUE,
    program VARCHAR(120) NOT NULL,
    graduation_year SMALLINT UNSIGNED NOT NULL,
    phone VARCHAR(30),
    gpa DECIMAL(4,2),
    resume_path VARCHAR(500),
    profile_summary TEXT,
    CONSTRAINT fk_students_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS student_preferences (
    student_user_id BIGINT UNSIGNED NOT NULL PRIMARY KEY,
    work_style ENUM('team', 'independent', 'balanced') NOT NULL,
    strength ENUM('problem_solving', 'communication', 'creative', 'organizing') NOT NULL,
    environment ENUM('structured', 'fast_paced', 'flexible') NOT NULL,
    preferred_role VARCHAR(120) NOT NULL,
    preferred_industry VARCHAR(100),
    employment_type ENUM('any', 'full-time', 'part-time', 'internship') NOT NULL DEFAULT 'any',
    work_mode ENUM('any', 'remote', 'hybrid', 'onsite') NOT NULL DEFAULT 'any',
    onboarding_complete BOOLEAN NOT NULL DEFAULT TRUE,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_student_preferences_student FOREIGN KEY (student_user_id) REFERENCES students(user_id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS recruiters (
    user_id BIGINT UNSIGNED NOT NULL PRIMARY KEY,
    company_name VARCHAR(160) NOT NULL,
    company_website VARCHAR(255),
    contact_phone VARCHAR(30),
    company_description TEXT,
    industry VARCHAR(120),
    company_location VARCHAR(160),
    company_size VARCHAR(80),
    logo_path VARCHAR(120),
    approved_at TIMESTAMP NULL,
    CONSTRAINT fk_recruiters_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS skills (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(80) NOT NULL UNIQUE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS student_skills (
    student_user_id BIGINT UNSIGNED NOT NULL,
    skill_id BIGINT UNSIGNED NOT NULL,
    PRIMARY KEY (student_user_id, skill_id),
    CONSTRAINT fk_student_skills_student FOREIGN KEY (student_user_id) REFERENCES students(user_id) ON DELETE CASCADE,
    CONSTRAINT fk_student_skills_skill FOREIGN KEY (skill_id) REFERENCES skills(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS jobs (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    recruiter_user_id BIGINT UNSIGNED NOT NULL,
    title VARCHAR(160) NOT NULL,
    description TEXT NOT NULL,
    location VARCHAR(160) NOT NULL,
    employment_type ENUM('internship', 'full-time', 'part-time', 'contract') NOT NULL,
    minimum_gpa DECIMAL(4,2),
    graduation_year SMALLINT UNSIGNED,
    status ENUM('pending', 'approved', 'rejected', 'closed') NOT NULL DEFAULT 'pending',
    application_deadline DATE,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_jobs_recruiter FOREIGN KEY (recruiter_user_id) REFERENCES recruiters(user_id),
    INDEX idx_jobs_status_deadline (status, application_deadline)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS applications (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    job_id BIGINT UNSIGNED NOT NULL,
    student_user_id BIGINT UNSIGNED NOT NULL,
    status ENUM('applied', 'under_review', 'shortlisted', 'interview', 'offered', 'rejected', 'withdrawn') NOT NULL DEFAULT 'applied',
    applied_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_application_student_job (student_user_id, job_id),
    CONSTRAINT fk_applications_job FOREIGN KEY (job_id) REFERENCES jobs(id) ON DELETE CASCADE,
    CONSTRAINT fk_applications_student FOREIGN KEY (student_user_id) REFERENCES students(user_id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Register a student first, then promote one trusted account manually if it should be an admin:
-- UPDATE users SET role = 'admin', status = 'active' WHERE email = 'trusted-admin@example.edu';
